# synchronousBallMovement
Ball moving synchronously
